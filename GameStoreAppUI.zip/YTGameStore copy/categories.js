export default categoryList = [
    "All",
    "Action",
    "Adventure",
    "Casual",
    "Indie",
    "Multiplayer",
    "Racing",
    "RPG",
    "Simulation",
    "Sports",
    "Strategy",
];
